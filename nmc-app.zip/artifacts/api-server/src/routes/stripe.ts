import { Router } from "express";
import { stripeStorage } from "../stripeStorage";
import { stripeService } from "../stripeService";
import { getUncachableStripeClient } from "../stripeClient";

const router = Router();

// ── Products & Prices ────────────────────────────────────────────────────────

/**
 * GET /api/stripe/products
 * Returns active products with their active prices, fetched live from Stripe.
 */
router.get("/products", async (_req, res) => {
  const stripe = getUncachableStripeClient();

  const [products, prices] = await Promise.all([
    stripe.products.list({ active: true, limit: 20 }),
    stripe.prices.list({ active: true, limit: 50 }),
  ]);

  const pricesByProduct = new Map<string, typeof prices.data>();
  for (const price of prices.data) {
    const productId = typeof price.product === "string" ? price.product : price.product.id;
    if (!pricesByProduct.has(productId)) pricesByProduct.set(productId, []);
    pricesByProduct.get(productId)!.push(price);
  }

  const data = products.data.map((p) => ({
    id: p.id,
    name: p.name,
    description: p.description,
    metadata: p.metadata,
    prices: (pricesByProduct.get(p.id) ?? []).map((pr) => ({
      id: pr.id,
      unit_amount: pr.unit_amount,
      currency: pr.currency,
      recurring: pr.recurring,
    })),
  }));

  res.json({ data });
});

// ── Checkout ─────────────────────────────────────────────────────────────────

/**
 * POST /api/stripe/checkout
 * Body: { priceId: string }
 * Requires: authenticated session (userId pulled from req.user)
 * Returns: { url } — redirect the browser here to complete checkout
 */
router.post("/checkout", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Not authenticated" });
  }

  const { priceId } = req.body as { priceId: string };
  if (!priceId) {
    return res.status(400).json({ error: "priceId is required" });
  }

  // userId is the OIDC sub — a string
  const userId: string = req.user!.id;
  const userEmail: string | undefined = (req.user as { email?: string }).email;

  const host = `${req.protocol}://${req.get("host")}`;
  const successUrl = `${host}/?checkout=success`;
  const cancelUrl = `${host}/`;

  let customerId: string | undefined;

  const dbUser = await stripeStorage.getUser(userId);
  if (dbUser?.stripeCustomerId) {
    customerId = dbUser.stripeCustomerId;
  } else {
    const resolvedEmail = userEmail ?? dbUser?.email ?? undefined;
    if (resolvedEmail) {
      const customer = await stripeService.createCustomer(resolvedEmail, userId);
      await stripeStorage.updateUserStripeInfo(userId, { stripeCustomerId: customer.id });
      customerId = customer.id;
    }
  }

  const session = await stripeService.createCheckoutSession(
    customerId ?? "",
    priceId,
    successUrl,
    cancelUrl
  );

  res.json({ url: session.url });
});

// ── Billing Portal ────────────────────────────────────────────────────────────

/**
 * POST /api/stripe/portal
 * Requires: authenticated session
 * Returns: { url } — redirect the browser here to manage the subscription
 */
router.post("/portal", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Not authenticated" });
  }

  const userId: string = req.user!.id;
  const dbUser = await stripeStorage.getUser(userId);

  if (!dbUser?.stripeCustomerId) {
    return res.status(404).json({ error: "No Stripe customer found for this user" });
  }

  const host = `${req.protocol}://${req.get("host")}`;
  const session = await stripeService.createPortalSession(dbUser.stripeCustomerId, `${host}/`);
  res.json({ url: session.url });
});

// ── Subscription Status ───────────────────────────────────────────────────────

/**
 * GET /api/stripe/subscription
 * Requires: authenticated session
 * Returns the Stripe subscription object for the current user.
 */
router.get("/subscription", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Not authenticated" });
  }

  const userId: string = req.user!.id;
  const dbUser = await stripeStorage.getUser(userId);

  if (!dbUser?.stripeSubscriptionId) {
    return res.json({ subscription: null });
  }

  const stripe = getUncachableStripeClient();
  const subscription = await stripe.subscriptions.retrieve(dbUser.stripeSubscriptionId);
  res.json({ subscription });
});

export default router;
