import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

/**
 * GET /api/users/me
 * Returns the full profile (including tier) for the currently authenticated user.
 */
router.get("/me", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, req.user.id));

  if (!user) return res.status(404).json({ error: "User not found" });

  res.json(user);
});

/**
 * GET /api/users
 * Returns all users — admin only. Add a real auth guard before going live.
 */
router.get("/", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const users = await db.select().from(usersTable);
  res.json(users);
});

/**
 * GET /api/users/:id
 * Returns a single user by id.
 */
router.get("/:id", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const { id } = req.params;
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, id));

  if (!user) return res.status(404).json({ error: "User not found" });

  res.json(user);
});

/**
 * PATCH /api/users/:id/tier
 * Body: { tier: "free" | "premium" }
 * Switches a user's subscription tier. Used by the admin panel.
 */
router.patch("/:id/tier", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const { id } = req.params;
  const { tier } = req.body as { tier: string };

  if (tier !== "free" && tier !== "premium") {
    return res.status(400).json({ error: 'tier must be "free" or "premium"' });
  }

  const [updated] = await db
    .update(usersTable)
    .set({ tier })
    .where(eq(usersTable.id, id))
    .returning();

  if (!updated) return res.status(404).json({ error: "User not found" });

  res.json(updated);
});

export default router;
