import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

/**
 * StripeStorage: Read and write Stripe-related data in the application database.
 *
 * Stripe objects (products, prices, subscriptions) are fetched live from the
 * Stripe API via stripeService.ts — we only persist the Stripe IDs and
 * subscription status here so we can look them up without an API call.
 *
 * NOTE: userId is the OIDC sub — a VARCHAR string, not a numeric id.
 */
export class StripeStorage {
  async getUser(id: string) {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, id));
    return user ?? null;
  }

  async getUserByStripeCustomerId(customerId: string) {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.stripeCustomerId, customerId));
    return user ?? null;
  }

  async updateUserStripeInfo(
    userId: string,
    info: { stripeCustomerId?: string; stripeSubscriptionId?: string }
  ) {
    const [user] = await db
      .update(usersTable)
      .set({ ...info, updatedAt: new Date() })
      .where(eq(usersTable.id, userId))
      .returning();
    return user;
  }

  /** Called by the webhook handler when a subscription is created or updated */
  async upsertSubscription(customerId: string, subscriptionId: string, status: string) {
    const user = await this.getUserByStripeCustomerId(customerId);
    if (!user) return; // customer not linked to any app user yet

    // Treat active + trialing as premium; anything else downgrades to free
    const isPremium = status === "active" || status === "trialing";

    await db
      .update(usersTable)
      .set({
        stripeSubscriptionId: subscriptionId,
        tier: isPremium ? "premium" : "free",
        updatedAt: new Date(),
      })
      .where(eq(usersTable.id, user.id));
  }

  /** Called by the webhook handler when a subscription is cancelled */
  async clearSubscription(customerId: string) {
    const user = await this.getUserByStripeCustomerId(customerId);
    if (!user) return;
    await db
      .update(usersTable)
      .set({ stripeSubscriptionId: null, tier: "free", updatedAt: new Date() })
      .where(eq(usersTable.id, user.id));
  }
}

export const stripeStorage = new StripeStorage();
