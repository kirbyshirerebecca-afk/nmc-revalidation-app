import Stripe from "stripe";
import { StripeSync } from "stripe-replit-sync";

/**
 * Reads Stripe credentials from environment variables.
 * Uses STRIPE_SECRET_KEY directly (no Replit connectors).
 */
function getStripeCredentials(): { secretKey: string } {
  const secretKey = process.env.STRIPE_SECRET_KEY;
  if (!secretKey) {
    throw new Error(
      "STRIPE_SECRET_KEY environment variable is required. " +
        "Add it via the Secrets tab in your Replit workspace."
    );
  }
  return { secretKey };
}

/**
 * Returns a fresh authenticated Stripe client.
 * Not cached — call fresh on every request.
 */
export function getUncachableStripeClient(): Stripe {
  const { secretKey } = getStripeCredentials();
  return new Stripe(secretKey);
}

/**
 * Returns a fresh StripeSync instance for webhook processing and data sync.
 * Not cached — call fresh on every request.
 */
export function getStripeSync(): StripeSync {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error("DATABASE_URL environment variable is required");
  }

  const { secretKey } = getStripeCredentials();
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET ?? "";

  return new StripeSync({
    poolConfig: { connectionString: databaseUrl },
    stripeSecretKey: secretKey,
    stripeWebhookSecret: webhookSecret,
  });
}
