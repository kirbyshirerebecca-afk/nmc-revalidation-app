import Stripe from "stripe";
import { getUncachableStripeClient } from "./stripeClient";
import { stripeStorage } from "./stripeStorage";

/**
 * Handles incoming Stripe webhook events.
 *
 * The webhook secret (STRIPE_WEBHOOK_SECRET) is used to verify the signature.
 * If not set, signature verification is skipped — fine for local dev, but must
 * be set in production.
 */
export class WebhookHandlers {
  static async processWebhook(payload: Buffer, signature: string): Promise<void> {
    if (!Buffer.isBuffer(payload)) {
      throw new Error(
        "Payload must be a Buffer. " +
          "This usually means express.json() ran before this route. " +
          "Register the webhook route BEFORE app.use(express.json())."
      );
    }

    const stripe = getUncachableStripeClient();
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

    let event: Stripe.Event;

    if (webhookSecret) {
      // Verify signature — required in production
      event = stripe.webhooks.constructEvent(payload, signature, webhookSecret);
    } else {
      // No secret set: parse without verification (dev only)
      event = JSON.parse(payload.toString()) as Stripe.Event;
    }

    await WebhookHandlers.handleEvent(event);
  }

  private static async handleEvent(event: Stripe.Event): Promise<void> {
    switch (event.type) {
      case "customer.subscription.created":
      case "customer.subscription.updated": {
        const sub = event.data.object as Stripe.Subscription;
        const customerId = typeof sub.customer === "string" ? sub.customer : sub.customer.id;
        await stripeStorage.upsertSubscription(customerId, sub.id, sub.status);
        break;
      }

      case "customer.subscription.deleted": {
        const sub = event.data.object as Stripe.Subscription;
        const customerId = typeof sub.customer === "string" ? sub.customer : sub.customer.id;
        await stripeStorage.clearSubscription(customerId);
        break;
      }

      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        if (session.mode === "subscription" && session.subscription && session.customer) {
          const customerId =
            typeof session.customer === "string" ? session.customer : session.customer.id;
          const subscriptionId =
            typeof session.subscription === "string"
              ? session.subscription
              : session.subscription.id;
          await stripeStorage.upsertSubscription(customerId, subscriptionId, "active");
        }
        break;
      }

      default:
        // Unhandled event types are silently ignored
        break;
    }
  }
}
