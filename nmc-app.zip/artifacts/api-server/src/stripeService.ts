import { getUncachableStripeClient } from "./stripeClient";

export class StripeService {
  /** Create a Stripe customer for a new subscriber */
  async createCustomer(email: string, userId: string) {
    const stripe = getUncachableStripeClient();
    return stripe.customers.create({
      email,
      metadata: { userId: String(userId) },
    });
  }

  /** Create a Stripe Billing checkout session for a subscription */
  async createCheckoutSession(
    customerId: string,
    priceId: string,
    successUrl: string,
    cancelUrl: string
  ) {
    const stripe = getUncachableStripeClient();
    return stripe.checkout.sessions.create({
      customer: customerId || undefined,
      payment_method_types: ["card"],
      line_items: [{ price: priceId, quantity: 1 }],
      mode: "subscription",
      // 30-day free trial — first month free, then £39.99/year
      subscription_data: { trial_period_days: 30 },
      success_url: successUrl,
      cancel_url: cancelUrl,
    });
  }

  /** Open the Stripe customer billing portal so users can manage their subscription */
  async createPortalSession(customerId: string, returnUrl: string) {
    const stripe = getUncachableStripeClient();
    return stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: returnUrl,
    });
  }
}

export const stripeService = new StripeService();
